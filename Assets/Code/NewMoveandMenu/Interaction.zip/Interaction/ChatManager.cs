using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ChatManager : MonoBehaviour
{
    [Header("UI ����")]
    public GameObject chatPanel;
    public Text chatText;
    public Text pressText; // [�߰�] "��Ŭ���� ���� ����" �ؽ�Ʈ

    [Header("ä�� ������")]
    public string[] chatMessages;
    public bool playOnStart = true;

    private Queue<string> chatQueue = new Queue<string>();
    private bool isChatting = false;

    public static bool IsChatting { get; private set; }

    void Start()
    {
        chatPanel.SetActive(false);
        pressText.gameObject.SetActive(false); // [�߰�] ���� �� ��Ȱ��ȭ

        if (playOnStart && chatMessages.Length > 0)
        {
            StartChat(chatMessages);
        }
    }

    public void StartChat(string[] messages)
    {
        if (messages == null || messages.Length == 0) return;

        chatQueue.Clear();
        foreach (string msg in messages)
        {
            chatQueue.Enqueue(msg);
        }

        chatPanel.SetActive(true);
        pressText.gameObject.SetActive(true); // [�߰�] Ȱ��ȭ
        isChatting = true;
        IsChatting = true;
        ShowNextChat();

        if (PlayerMove.Instance != null)
            PlayerMove.Instance.enabled = false;

        if (RaycastInteractor.Instance != null)
            RaycastInteractor.Instance.enabled = false;
    }
    void Update()
    {
        if (!isChatting) return;

        // [����] GetMouseButtonDown �� GetKeyDown(KeyCode.Mouse0)
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            ShowNextChat();
        }
    }

    private void ShowNextChat()
    {
        if (chatQueue.Count == 0)
        {
            EndChat();
            return;
        }

        chatText.text = chatQueue.Dequeue();

        // [����] ������ �޽��������� pressText ����
        /* ������ �κ�
        if (chatQueue.Count == 0)
        {
            pressText.gameObject.SetActive(false);
        }
        */
    }

    private void EndChat()
    {
        chatPanel.SetActive(false);
        pressText.gameObject.SetActive(false); // ä�� ���� �� ����
        isChatting = false;
        IsChatting = false;

        if (PlayerMove.Instance != null)
            PlayerMove.Instance.enabled = true;

        if (RaycastInteractor.Instance != null)
            RaycastInteractor.Instance.enabled = true;
    }
}
