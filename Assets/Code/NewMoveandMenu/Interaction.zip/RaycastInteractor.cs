using UnityEngine;

public class RaycastInteractor : MonoBehaviour
{
    [Header("��ȣ�ۿ� ����")]
    public string targetTag = "Interactable"; // ������ �±� �̸�
    public float detectDistance = 2f;         // ���� �Ÿ�(����)
    public Color highlightColor = Color.red;  // ���̶���Ʈ ����

    private Renderer lastRenderer;            // ���������� ���̶���Ʈ�� ������Ʈ�� Renderer
    private Color originalColor;              // ���� ���� ����

    void Update()
    {
        HandleRaycastInteraction();
    }

    public interface IInteractable
    {
        void Interact();
    }

    void HandleRaycastInteraction()
    {
        RaycastHit hit;
        bool detected = Physics.Raycast(
            Camera.main.transform.position,
            Camera.main.transform.forward,
            out hit,
            detectDistance
        );

        if (detected && hit.collider.CompareTag(targetTag))
        {
            Renderer rend = hit.collider.GetComponent<Renderer>();
            if (rend != null)
            {
                if (rend != lastRenderer)
                {
                    RemoveHighlight();
                    lastRenderer = rend;
                    originalColor = rend.material.color;
                    rend.material.color = highlightColor;
                }

                // ��Ŭ�� �� ��ȣ�ۿ�
                if (Input.GetMouseButtonDown(0))
                {
                    IInteractable interactable = hit.collider.GetComponent<IInteractable>();
                    if (interactable != null)
                    {
                        interactable.Interact();
                    }
                }
            }
        }
        else
        {
            RemoveHighlight();
        }
    }


    void RemoveHighlight()
    {
        if (lastRenderer != null)
        {
            lastRenderer.material.color = originalColor;
            lastRenderer = null;
        }
    }

    void OnDisable()
    {
        RemoveHighlight();
    }
}
